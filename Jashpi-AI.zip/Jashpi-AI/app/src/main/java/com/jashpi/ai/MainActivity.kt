package com.jashpi.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/** Hosts the simple HTML UI (assets/www) and exposes the phone's powers to it through window.Jashpi. */
class MainActivity : Activity() {

    companion object {
        @Volatile
        var inst: MainActivity? = null

        // SHA-256 of the developer code. Only the hash lives in the app.
        private const val DEV_HASH = "07ae20918563b4a84e4458725d1b9f7296da63e3b51c1d5e23b7875462d078d4"
        private const val RC_PERM = 7
        private const val RC_GAL = 11
        private const val RC_CAM = 12
    }

    private lateinit var web: WebView
    private var ready = false
    private val pending = ArrayList<String>()
    private var camUri: Uri? = null
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inst = this
        web = WebView(this)
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Jashpi")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "file") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    toast("No app found to open this")
                }
                return true
            }
        }
        web.loadUrl("file:///android_asset/www/index.html")
        tts = TextToSpeech(this) { status -> ttsOk = status == TextToSpeech.SUCCESS }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val act = i.getStringExtra("act")
        if (act != null) {
            js("onNative(" + JSONObject().put("act", act).put("text", i.getStringExtra("text") ?: "") + ")")
            i.removeExtra("act")
        }
        if (i.action == Intent.ACTION_SEND && i.type == "text/plain") {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!t.isNullOrEmpty()) js("onNative(" + JSONObject().put("act", "scantext").put("text", t) + ")")
            i.action = null
        }
    }

    /** Run JavaScript in the page (queued until the page says it is ready). */
    fun js(code: String) {
        runOnUiThread {
            if (ready) web.evaluateJavascript(code, null) else pending.add(code)
        }
    }

    private fun toast(m: String) {
        runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun askPerms() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.ACCESS_FINE_LOCATION)
        list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        list.add(Manifest.permission.SEND_SMS)
        list.add(Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = list.filter { !has(it) }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), RC_PERM) else afterPerms()
    }

    private fun afterPerms() {
        Sos.warm(this)
        WakeService.act(this, null)
        js("onNative(" + JSONObject().put("act", "perms") + ")")
        if (!Settings.canDrawOverlays(this) && !St.sp(this).getBoolean("overlayAsked", false)) {
            St.sp(this).edit().putBoolean("overlayAsked", true).apply()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RC_PERM) afterPerms()
    }

    /* ----------------------------------------------------------- image / qr */

    private fun encode(uri: Uri?): String? {
        if (uri == null) return null
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / ss > 1600 || o.outHeight / ss > 1600) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) {
                null
            } else {
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            null
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != RC_GAL && requestCode != RC_CAM) return
        if (resultCode != RESULT_OK) {
            js("onImage(null)")
            return
        }
        val uri = if (requestCode == RC_CAM) camUri else data?.data
        Thread {
            val b64 = encode(uri)
            js("onImage(" + (if (b64 == null) "null" else JSONObject.quote(b64)) + ")")
        }.start()
    }

    /* ---------------------------------------------------------------- voice */

    private fun listenOnce() {
        runOnUiThread {
            if (!has(Manifest.permission.RECORD_AUDIO)) {
                askPerms()
                return@runOnUiThread
            }
            WakeService.act(this, WakeService.A_PAUSE)
            try {
                sr?.destroy()
                val r = SpeechRecognizer.createSpeechRecognizer(this)
                sr = r
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        js("onVoice('', 'ready')")
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}

                    override fun onError(error: Int) {
                        js("onVoice('', 'error')")
                        WakeService.act(this@MainActivity, WakeService.A_RESUME)
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                        js("onVoice(" + JSONObject.quote(t) + ", 'partial')")
                    }

                    override fun onResults(results: Bundle?) {
                        WakeService.act(this@MainActivity, WakeService.A_RESUME)
                        val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                        if (t.isBlank()) {
                            js("onVoice('', 'error')")
                            return
                        }
                        val cmd = Commands.parse(t.lowercase())
                        if (cmd == Cmd.NONE) {
                            js("onVoice(" + JSONObject.quote(t) + ", 'final')")
                        } else {
                            js("onNative(" + JSONObject().put("act", "cmd").put("cmd", cmd.name).put("text", t) + ")")
                            Actions.run(this@MainActivity, cmd, t)
                        }
                    }
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                val lang = St.json(this).optString("lang", "hn")
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "en") "en-IN" else "hi-IN")
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                r.startListening(i)
            } catch (e: Exception) {
                js("onVoice('', 'error')")
                WakeService.act(this, WakeService.A_RESUME)
            }
        }
    }

    private fun speak(text: String, lang: String) {
        runOnUiThread {
            if (!ttsOk) return@runOnUiThread
            tts?.language = if (lang == "en") Locale("en", "IN") else Locale("hi", "IN")
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jashpi")
        }
    }

    override fun onBackPressed() {
        js("onNative(" + JSONObject().put("act", "back") + ")")
    }

    override fun onDestroy() {
        inst = null
        try {
            sr?.destroy()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    /* --------------------------------------------------------------- bridge */

    inner class Bridge {
        @JavascriptInterface
        fun ready() {
            runOnUiThread {
                ready = true
                for (c in pending) web.evaluateJavascript(c, null)
                pending.clear()
            }
        }

        @JavascriptInterface
        fun sync(json: String) {
            St.save(this@MainActivity, json)
            WakeService.act(this@MainActivity, WakeService.A_RELOAD)
        }

        @JavascriptInterface
        fun relay(): String = St.relay(this@MainActivity)

        @JavascriptInterface
        fun askPerms() {
            runOnUiThread { this@MainActivity.askPerms() }
        }

        @JavascriptInterface
        fun perms(): String = JSONObject()
            .put("mic", has(Manifest.permission.RECORD_AUDIO))
            .put("loc", has(Manifest.permission.ACCESS_FINE_LOCATION))
            .put("sms", has(Manifest.permission.SEND_SMS))
            .put("call", has(Manifest.permission.CALL_PHONE))
            .put("overlay", Settings.canDrawOverlays(this@MainActivity))
            .toString()

        @JavascriptInterface
        fun status(): String = JSONObject()
            .put("service", WakeService.running)
            .put("siren", Siren.active)
            .put("live", Live.on(this@MainActivity))
            .put("liveId", Live.id(this@MainActivity))
            .toString()

        @JavascriptInterface
        fun sos(silent: Boolean) {
            val c = applicationContext
            Thread { Sos.dispatch(c, silent) }.start()
        }

        @JavascriptInterface
        fun stopAlerts() {
            Sos.stopStrobe()
            Siren.off()
        }

        @JavascriptInterface
        fun liveStart(): String {
            val id = Live.ensure(this@MainActivity)
            WakeService.act(this@MainActivity, WakeService.A_LIVE_START)
            Live.setOn(this@MainActivity, true)
            return id
        }

        @JavascriptInterface
        fun liveStop() {
            WakeService.act(this@MainActivity, WakeService.A_LIVE_STOP)
            Live.setOn(this@MainActivity, false)
        }

        @JavascriptInterface
        fun mic() = listenOnce()

        @JavascriptInterface
        fun speak(text: String, lang: String) = this@MainActivity.speak(text, lang)

        @JavascriptInterface
        fun stopSpeak() {
            runOnUiThread { tts?.stop() }
        }

        @JavascriptInterface
        fun scanQr() {
            runOnUiThread {
                try {
                    GmsBarcodeScanning.getClient(this@MainActivity).startScan()
                        .addOnSuccessListener { bc -> js("onQr(" + JSONObject.quote(bc.rawValue ?: "") + ")") }
                        .addOnCanceledListener { js("onQr(null)") }
                        .addOnFailureListener { e -> js("onQr(null," + JSONObject.quote(e.message ?: "scan failed") + ")") }
                } catch (e: Exception) {
                    js("onQr(null,'scanner unavailable')")
                }
            }
        }

        @JavascriptInterface
        fun pickImage(camera: Boolean) {
            runOnUiThread {
                try {
                    if (camera) {
                        val dir = File(cacheDir, "shots")
                        dir.mkdirs()
                        val f = File(dir, "shot_" + System.currentTimeMillis() + ".jpg")
                        val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", f)
                        camUri = uri
                        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                        i.putExtra(MediaStore.EXTRA_OUTPUT, uri)
                        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivityForResult(i, RC_CAM)
                    } else {
                        val i = Intent(Intent.ACTION_GET_CONTENT)
                        i.type = "image/*"
                        i.addCategory(Intent.CATEGORY_OPENABLE)
                        startActivityForResult(Intent.createChooser(i, "Choose image"), RC_GAL)
                    }
                } catch (e: Exception) {
                    toast("Camera / gallery not available")
                    js("onImage(null)")
                }
            }
        }

        @JavascriptInterface
        fun open(url: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                    toast("No app found")
                }
            }
        }

        @JavascriptInterface
        fun whatsapp(phone: String, text: String) {
            val p = phone.replace(Regex("[^0-9]"), "")
            open("https://wa.me/" + p + "?text=" + Uri.encode(text))
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, "Share"))
            }
        }

        @JavascriptInterface
        fun call(phone: String) {
            val c = applicationContext
            Thread { Sos.call(c, phone.replace(Regex("[^+0-9]"), "")) }.start()
        }

        @JavascriptInterface
        fun toast(m: String) = this@MainActivity.toast(m)

        @JavascriptInterface
        fun exit() {
            runOnUiThread { moveTaskToBack(true) }
        }

        /** Developer code check. The code is compared by hash and is never written into the UI or sent anywhere except to your own relay. */
        @JavascriptInterface
        fun checkDev(code: String): Boolean {
            val h = MessageDigest.getInstance("SHA-256").digest(code.trim().toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
            val ok = h == DEV_HASH
            if (ok) St.sp(this@MainActivity).edit().putString("devcode", code.trim()).apply()
            return ok
        }

        @JavascriptInterface
        fun devPost(path: String, body: String, cb: String) {
            val c = this@MainActivity
            Thread {
                val code = St.sp(c).getString("devcode", "") ?: ""
                val res = if (code.isEmpty()) null else try {
                    val o = JSONObject(body)
                    o.put("code", code)
                    Net.post(St.relay(c) + path, o.toString())
                } catch (e: Exception) {
                    null
                }
                js("onDevResult(" + JSONObject.quote(cb) + "," + JSONObject.quote(res ?: "") + ")")
            }.start()
        }
    }
}
