package com.jashpi.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject

/** Physical + digital SOS. Physical: vibration + flashlight strobe + "show to helper" screen. Digital: SMS, Telegram, live link, call. */
object Sos {
    @Volatile
    private var last = 0L

    @Volatile
    private var strobing = false

    fun has(c: Context, p: String): Boolean = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun lastLocation(c: Context): Location? {
        if (!has(c, Manifest.permission.ACCESS_FINE_LOCATION) && !has(c, Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        return try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            best
        } catch (e: Exception) {
            null
        }
    }

    /** Ask the phone for one fresh fix so "last known location" is not empty. */
    @Suppress("DEPRECATION")
    fun warm(c: Context) {
        if (!has(c, Manifest.permission.ACCESS_FINE_LOCATION)) return
        try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            }
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.isProviderEnabled(p)) lm.requestSingleUpdate(p, l, Looper.getMainLooper())
            }
        } catch (e: Exception) {
        }
    }

    fun battery(c: Context): Int {
        return try {
            (c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        } catch (e: Exception) {
            -1
        }
    }

    private fun words(lang: String): String = when (lang) {
        "hi" -> "सुरक्षित नहीं है, मुसीबत में है, लोकेशन:"
        "en" -> "is not safe, problem, location:"
        else -> "safe nahi hai, problem mein hai, location:"
    }

    fun message(c: Context, st: JSONObject, loc: Location?, live: String): String {
        val name = st.optString("name").ifEmpty { "User" }
        val map = if (loc == null) "(location unavailable)" else "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        val sb = StringBuilder("$name ${words(st.optString("lang"))} $map")
        val b = battery(c)
        if (b >= 0) sb.append(" | Battery $b%")
        val med = listOf(st.optString("blood").let { if (it.isEmpty()) "" else "Blood $it" }, st.optString("note")).filter { it.isNotEmpty() }
        if (med.isNotEmpty()) sb.append(" | ").append(med.joinToString(", "))
        sb.append(" | Live: ").append(live)
        return sb.toString()
    }

    @Suppress("DEPRECATION")
    private fun smsManager(c: Context): SmsManager {
        return if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
    }

    private fun phones(st: JSONObject): List<String> {
        val out = ArrayList<String>()
        val a = st.optJSONArray("contacts") ?: JSONArray()
        for (i in 0 until a.length()) {
            val n = a.optJSONObject(i)?.optString("phone", "")?.replace(Regex("[^+0-9]"), "") ?: ""
            if (n.isNotEmpty()) out.add(n)
        }
        return out
    }

    /** Runs the whole SOS. Call from a background thread. */
    fun dispatch(c: Context, silent: Boolean) {
        val now = System.currentTimeMillis()
        if (now - last < 15000) return
        last = now
        val st = St.json(c)
        var loc = lastLocation(c)
        if (loc == null) {
            warm(c)
            var n = 0
            while (loc == null && n < 4) {
                try {
                    Thread.sleep(1000)
                } catch (e: Exception) {
                }
                loc = lastLocation(c)
                n++
            }
        }
        if (!silent) physical(c)

        // digital: start live tracking so the "Live:" link works, then notify everyone
        val liveId = Live.ensure(c)
        WakeService.act(c, WakeService.A_LIVE_START)
        val live = "${St.relay(c)}/t/$liveId"
        val text = message(c, st, loc, live)
        val nums = phones(st)

        var smsOk = 0
        if (nums.isNotEmpty() && has(c, Manifest.permission.SEND_SMS)) {
            try {
                val sm = smsManager(c)
                for (n in nums) {
                    try {
                        sm.sendMultipartTextMessage(n, null, sm.divideMessage(text), null, null)
                        smsOk++
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
            }
        }

        var tgSent = 0
        val code = st.optString("code")
        if (code.length == 16) {
            try {
                val o = JSONObject().put("code", code).put("ids", st.optJSONArray("tg") ?: JSONArray()).put("text", text)
                if (loc != null) o.put("lat", loc.latitude).put("lng", loc.longitude)
                val res = Net.post(St.relay(c) + "/sos", o.toString())
                if (res != null) tgSent = JSONObject(res).optInt("sent", 0)
            } catch (e: Exception) {
            }
        }

        if (!silent && nums.isNotEmpty()) call(c, nums[0])

        if (silent) return
        MainActivity.inst?.js(
            "onNative(" + JSONObject().put("act", "sos_done").put("sms", smsOk).put("tg", tgSent)
                .put("contacts", nums.size).put("liveId", liveId).put("text", text) + ")"
        )
    }

    /** "call mummy" -> that contact; plain "call karo" -> first contact. */
    fun callByText(c: Context, text: String) {
        val a = St.json(c).optJSONArray("contacts") ?: JSONArray()
        val t = text.lowercase()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val n = o.optString("name", "").trim().lowercase()
            val ph = o.optString("phone", "").replace(Regex("[^+0-9]"), "")
            if (n.isNotEmpty() && ph.isNotEmpty() && t.contains(n)) {
                call(c, ph)
                return
            }
        }
        callFirst(c)
    }

    fun callFirst(c: Context) {
        val n = phones(St.json(c))
        if (n.isNotEmpty()) call(c, n[0])
    }

    fun call(c: Context, number: String) {
        val uri = Uri.fromParts("tel", number, null)
        try {
            if (has(c, Manifest.permission.CALL_PHONE)) {
                val overlay = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(c)
                if (overlay) {
                    c.startActivity(Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).placeCall(uri, Bundle())
                }
            } else {
                c.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
        }
    }

    /** Physical alert: strong vibration and a flashlight strobe other people can notice. */
    fun physical(c: Context) {
        try {
            @Suppress("DEPRECATION")
            val v = c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 150, 400, 150, 400), -1))
        } catch (e: Exception) {
        }
        strobe(c, 25000)
    }

    fun stopStrobe() {
        strobing = false
    }

    private fun strobe(c: Context, ms: Long) {
        if (strobing) return
        strobing = true
        Thread {
            var cm: CameraManager? = null
            var id: String? = null
            try {
                cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                for (cid in cm.cameraIdList) {
                    if (cm.getCameraCharacteristics(cid).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                        id = cid
                        break
                    }
                }
                if (id != null) {
                    val end = System.currentTimeMillis() + ms
                    var on = false
                    while (strobing && System.currentTimeMillis() < end) {
                        on = !on
                        cm.setTorchMode(id, on)
                        Thread.sleep(250)
                    }
                }
            } catch (e: Exception) {
            } finally {
                try {
                    if (cm != null && id != null) cm.setTorchMode(id, false)
                } catch (e: Exception) {
                }
                strobing = false
            }
        }.start()
    }
}
