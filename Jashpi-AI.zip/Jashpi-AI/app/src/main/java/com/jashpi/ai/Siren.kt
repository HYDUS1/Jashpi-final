package com.jashpi.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin

/** Loud wailing siren. Only ever started by a voice command ("siren bajao"). */
object Siren {
    @Volatile
    var active = false
        private set
    private var thread: Thread? = null

    fun on(c: Context) {
        if (active) return
        active = true
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (e: Exception) {
        }
        thread = Thread {
            val rate = 22050
            val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            var track: AudioTrack? = null
            try {
                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val buf = ShortArray(rate / 10)
                var phase = 0.0
                var t = 0.0
                while (active) {
                    for (i in buf.indices) {
                        val f = 1000.0 + 450.0 * sin(2.0 * PI * 0.6 * t) // slow rising/falling wail
                        phase += 2.0 * PI * f / rate
                        buf[i] = if (sin(phase) >= 0.0) 30000 else -30000 // square wave = loudest
                        t += 1.0 / rate
                    }
                    track.write(buf, 0, buf.size)
                }
            } catch (e: Exception) {
                active = false
            } finally {
                try {
                    track?.stop()
                    track?.release()
                } catch (e: Exception) {
                }
            }
        }
        thread?.start()
    }

    fun off() {
        active = false
    }
}
