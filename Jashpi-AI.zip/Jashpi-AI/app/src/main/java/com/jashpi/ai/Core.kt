package com.jashpi.ai

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom

/** App state. The web UI owns it and pushes the whole JSON here with Jashpi.sync(). */
object St {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("jashpi", Context.MODE_PRIVATE)

    fun json(c: Context): JSONObject {
        return try {
            JSONObject(sp(c).getString("state", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
    }

    fun save(c: Context, s: String) {
        sp(c).edit().putString("state", s).apply()
        Commands.load(c)
    }

    fun relay(c: Context): String {
        val r = json(c).optString("relay")
        return (if (r.isNotEmpty()) r else BuildConfig.RELAY_URL).trimEnd('/')
    }
}

object Net {
    /** Generic blocking request. Returns (status, body) or null if the network failed. */
    fun request(url: String, method: String, body: String, ctype: String): Pair<Int, String>? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = 40000
            if (method != "GET") {
                c.doOutput = true
                c.setRequestProperty("Content-Type", if (ctype.isEmpty()) "application/json" else ctype)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code < 400) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            c.disconnect()
            Pair(code, txt)
        } catch (e: Exception) {
            null
        }
    }

    /** Blocking JSON POST. Returns the response body, or null on network failure. Call from a background thread. */
    fun post(url: String, json: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 8000
            c.readTimeout = 15000
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code < 400) c.inputStream else c.errorStream
            val out = stream?.bufferedReader()?.use { it.readText() } ?: ""
            c.disconnect()
            out
        } catch (e: Exception) {
            null
        }
    }
}

/** Live-location session id (shared by the service, SOS and the UI). */
object Live {
    private const val ALPHA = "abcdefghijkmnpqrstuvwxyz23456789"

    fun rnd(n: Int): String {
        val r = SecureRandom()
        val sb = StringBuilder()
        for (i in 0 until n) sb.append(ALPHA[r.nextInt(ALPHA.length)])
        return sb.toString()
    }

    fun id(c: Context): String = St.sp(c).getString("liveId", "") ?: ""

    fun ensure(c: Context): String {
        var i = id(c)
        if (i.isEmpty()) {
            i = rnd(10)
            St.sp(c).edit().putString("liveId", i).apply()
        }
        return i
    }

    fun on(c: Context): Boolean = St.sp(c).getBoolean("liveOn", false)

    fun setOn(c: Context, v: Boolean) {
        val e = St.sp(c).edit().putBoolean("liveOn", v)
        if (!v) e.remove("liveId")
        e.apply()
    }
}

enum class Cmd { SIREN_ON, SIREN_OFF, SOS, LOC_ON, LOC_OFF, SCAN, CALL, NEARBY, NONE }

/** Voice command parser (English, Hindi, Hinglish). Input is already lower-case. */
object Commands {
    private val sirenOn = Regex("(siren|sayren|सायरन|सायरेन)\\s*(baja|bajao|bajaao|bajado|bajana|chalu|chalao|on|start|बजा|बजाओ|चालू|चला)")
    private val sirenOff = Regex("(siren|sayren|सायरन|सायरेन)\\s*(band|bandh|bund|off|stop|roko|ruk|बंद|बन्द|रोको)")
    private val sosWord = Regex("\\bsos\\b|एसओएस")
    private val sosVerb = Regex("bhejo|bhej|send|karo|kar do|भेजो|भेज|करो")
    private val locWord = Regex("location|lokation|लोकेशन")
    private val locOn = Regex("share|bhejo|bhej|chalu|start|on\\b|शेयर|भेजो|भेज|चालू")
    private val locOff = Regex("band|bandh|stop|off\\b|बंद|रोको")
    private val scanWord = Regex("scan|स्कैन|स्केन|\\bqr\\b|क्यूआर")
    private val nearPlace = Regex("hospital|haspatal|aspatal|अस्पताल|हॉस्पिटल|police|पुलिस|thana|थाना|medical|pharmacy|दवाई")
    private val nearWord = Regex("near|paas|pass|kahan|kaha|dikhao|dikha|batao|dhundo|khojo|nazdeek|nazdik|पास|कहाँ|कहां|दिखाओ|बताओ|नज़दीक|नजदीक|खोजो|ढूंढो")
    private val callWord = Regex("\\bcall\\b|कॉल|फोन")
    private val callVerb = Regex("karo|kar do|lagao|laga do|करो|लगाओ|लगा दो")

    @Volatile
    var names: List<String> = emptyList()

    /** Remember contact names so "call mummy" can be understood. */
    fun load(c: Context) {
        val out = ArrayList<String>()
        val a = St.json(c).optJSONArray("contacts")
        if (a != null) {
            for (i in 0 until a.length()) {
                val n = a.optJSONObject(i)?.optString("name", "")?.trim()?.lowercase() ?: ""
                if (n.isNotEmpty()) out.add(n)
            }
        }
        names = out
    }

    fun parse(t: String): Cmd {
        if (t.isBlank()) return Cmd.NONE
        if (sirenOff.containsMatchIn(t)) return Cmd.SIREN_OFF
        if (sirenOn.containsMatchIn(t)) return Cmd.SIREN_ON
        if (locWord.containsMatchIn(t)) {
            if (locOff.containsMatchIn(t)) return Cmd.LOC_OFF
            if (locOn.containsMatchIn(t)) return Cmd.LOC_ON
        }
        if (sosWord.containsMatchIn(t) && sosVerb.containsMatchIn(t)) return Cmd.SOS
        if (nearPlace.containsMatchIn(t) && nearWord.containsMatchIn(t)) return Cmd.NEARBY
        if (scanWord.containsMatchIn(t)) return Cmd.SCAN
        if (callWord.containsMatchIn(t) && (callVerb.containsMatchIn(t) || names.any { t.contains(it) })) return Cmd.CALL
        return Cmd.NONE
    }
}

/** Runs a voice command no matter who heard it (background service or the open app). */
object Actions {
    fun run(c: Context, cmd: Cmd, text: String) {
        val app = c.applicationContext
        when (cmd) {
            Cmd.SIREN_ON -> Siren.on(app)
            Cmd.SIREN_OFF -> Siren.off()
            Cmd.SOS -> Thread { Sos.dispatch(app, false) }.start()
            Cmd.LOC_ON -> {
                Live.ensure(app)
                WakeService.act(app, WakeService.A_LIVE_START)
                openUi(app, "live", text)
            }
            Cmd.LOC_OFF -> WakeService.act(app, WakeService.A_LIVE_STOP)
            Cmd.SCAN -> openUi(app, "scan", text)
            Cmd.NEARBY -> openUi(app, "nearby", text)
            Cmd.CALL -> Thread { Sos.callByText(app, text) }.start()
            Cmd.NONE -> openUi(app, "ask", text)
        }
    }

    /** Brings the UI forward (works from the background because the user granted "display over other apps"). */
    fun openUi(c: Context, act: String, text: String) {
        try {
            val i = Intent(c, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra("act", act)
            i.putExtra("text", text)
            c.startActivity(i)
        } catch (e: Exception) {
        }
    }
}
