package com.jashpi.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Foreground service that keeps working with the screen off:
 *  - listens for "Hello Jashpi" (+ command), "bachao" x3, "madad/help" x3, cough x3 (silent SOS)
 *  - shake x5 / fall -> SOS
 *  - live location tracking (Telegram live location + web tracking link)
 */
class WakeService : Service(), RecognitionListener, SensorEventListener {

    companion object {
        const val CH = "jashpi_listen"
        const val NID = 4107
        const val A_LIVE_START = "live_start"
        const val A_LIVE_STOP = "live_stop"
        const val A_SIREN_OFF = "siren_off"
        const val A_PAUSE = "pause"
        const val A_RESUME = "resume"
        const val A_RELOAD = "reload"
        const val A_WALK_START = "walk_start"
        const val A_WALK_STOP = "walk_stop"

        @Volatile
        var running = false

        fun canRun(c: Context): Boolean =
            Sos.has(c, Manifest.permission.RECORD_AUDIO) ||
                Sos.has(c, Manifest.permission.ACCESS_FINE_LOCATION) ||
                Sos.has(c, Manifest.permission.ACCESS_COARSE_LOCATION)

        /** Start the service (a == null) or send it an action. Safe to call from anywhere. */
        fun act(c: Context, a: String?) {
            val ctrl = a == A_PAUSE || a == A_RESUME || a == A_RELOAD || a == A_SIREN_OFF || a == A_LIVE_STOP || a == A_WALK_STOP
            if (!running && ctrl) {
                if (a == A_SIREN_OFF) Siren.off()
                return
            }
            if (!canRun(c)) return
            val i = Intent(c, WakeService::class.java)
            if (a != null) i.action = a
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {
            }
        }

        private val WAKE = Regex(
            "(?:(?:he?l+o+|hallo|hailo|helo)\\s*)?j[a-z]{0,2}[sh]{1,2}\\s*[pbf][a-z]{0,2}\\b|" +
                "(?:ह[ेैा]?ल+[ोौ]?\\s*)?ज[ाैेि]?[शसष]्?\\s*[पबफ][ीिे]?"
        )
        private val BACHAO = Regex("bacha+o|bachau|bachav|bachaw|bachha+o|bacho\\b|बचाओ|बचाव|बचाऊ|बचा\\s*ओ")
        private val HELP = Regex("help me|हेल्प मी|madad|madat|mdad|मदद|मदत")
    }

    private val main = Handler(Looper.getMainLooper())
    private val listenRun = Runnable { listen() }
    private var sr: SpeechRecognizer? = null
    private var am: AudioManager? = null
    private var sm: SensorManager? = null
    private var lm: LocationManager? = null
    private var muted = false
    private var paused = false
    private var wantListen = true
    private var wantShake = true
    private var wantFall = true
    private var wantCough = false
    private var lang = "hn"

    private val bachao = ArrayList<Long>()
    private val help = ArrayList<Long>()
    private val cough = ArrayList<Long>()
    private val shakes = ArrayList<Long>()
    private var lastB = 0
    private var lastH = 0
    private var burstStart = 0L
    private var awaitUntil = 0L
    private var lastBeep = 0L
    private var lastSos = 0L
    private var freeFall = 0L
    private var handled = false

    private fun note(t: String) {
        St.sp(this).edit().putString("heard", t.take(60)).putLong("heardAt", System.currentTimeMillis()).apply()
    }

    // live location
    private var liveSent = false
    private var lastPost = 0L
    private val liveTick = object : Runnable {
        override fun run() {
            if (!running || !Live.on(this@WakeService)) return
            val l = Sos.lastLocation(this@WakeService)
            if (l != null) postLocation(l) else Sos.warm(this@WakeService)
            main.postDelayed(this, 5000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Jashpi protection", NotificationManager.IMPORTANCE_LOW))
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, notif(), fgType()) else startForeground(NID, notif())
        } catch (e: Exception) {
            stopSelf()
            return
        }
        running = true
        Commands.load(this)
        applyState()
        if (Live.on(this)) beginTracking()
    }

    private fun fgType(): Int {
        var t = 0
        if (Sos.has(this, Manifest.permission.RECORD_AUDIO)) t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (Sos.has(this, Manifest.permission.ACCESS_FINE_LOCATION) || Sos.has(this, Manifest.permission.ACCESS_COARSE_LOCATION)) {
            t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        return t
    }

    @Suppress("DEPRECATION")
    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val off = PendingIntent.getForegroundService(
            this, 1, Intent(this, WakeService::class.java).setAction(A_SIREN_OFF), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("Jashpi is protecting you")
            .setContentText("Say \"Hello Jashpi\" or \"Bachao\" 3 times")
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(R.drawable.ic_stat, "Siren off", off)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            A_LIVE_START -> {
                Live.ensure(this)
                Live.setOn(this, true)
                liveSent = false
                beginTracking()
            }
            A_LIVE_STOP -> endTracking()
            A_SIREN_OFF -> Siren.off()
            A_PAUSE -> {
                paused = true
                main.removeCallbacks(listenRun)
                try {
                    sr?.cancel()
                } catch (e: Exception) {
                }
                mute(false)
            }
            A_RESUME -> {
                paused = false
                if (wantListen) main.postDelayed(listenRun, 400)
            }
            A_RELOAD -> applyState()
            A_WALK_START -> startWalk(St.sp(this).getInt("walkMin", 15))
            A_WALK_STOP -> stopWalk()
        }
        return START_STICKY
    }

    /* ------------------------------------------------ safe walk (check-in timer) */
    private var walkRun: Runnable? = null
    private var walkFire: Runnable? = null

    private fun startWalk(min: Int) {
        stopWalk()
        val m = if (min < 1) 1 else min
        St.sp(this).edit().putLong("walkEnd", System.currentTimeMillis() + m * 60000L).apply()
        val r = Runnable {
            // time is up: ask "are you safe?" on screen; if nobody answers within ~30 s, send SOS
            Actions.openUi(applicationContext, "walk", "")
            val f = Runnable {
                St.sp(this).edit().remove("walkEnd").apply()
                fire(false)
            }
            walkFire = f
            main.postDelayed(f, 32000)
        }
        walkRun = r
        main.postDelayed(r, m * 60000L)
    }

    private fun stopWalk() {
        walkRun?.let { main.removeCallbacks(it) }
        walkFire?.let { main.removeCallbacks(it) }
        walkRun = null
        walkFire = null
        St.sp(this).edit().remove("walkEnd").apply()
    }

    /** Re-read toggles from the saved app state. */
    private fun applyState() {
        val st = St.json(this)
        wantListen = st.optBoolean("listen", true)
        wantShake = st.optBoolean("shake", true)
        wantFall = st.optBoolean("fall", true)
        wantCough = st.optBoolean("cough", false)
        lang = st.optString("lang", "hn")
        sm?.unregisterListener(this)
        if (wantShake || wantFall) {
            val s = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) sm?.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
        }
        main.removeCallbacks(listenRun)
        if (wantListen && !paused) {
            main.post(listenRun)
        } else {
            try {
                sr?.cancel()
                sr?.destroy()
            } catch (e: Exception) {
            }
            sr = null
            mute(false)
        }
    }

    /* ------------------------------------------------------------------ voice */

    private fun listen() {
        if (!running || !wantListen || paused) return
        if (!Sos.has(this, Manifest.permission.RECORD_AUDIO)) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try {
            sr?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(this)
            sr = r
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "en") "en-IN" else "hi-IN")
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            quiet(1500)
            lastB = 0
            lastH = 0
            handled = false
            r.startListening(i)
        } catch (e: Exception) {
            restart(2000)
        }
    }

    private fun restart(delay: Long) {
        main.removeCallbacks(listenRun)
        if (running && wantListen && !paused) main.postDelayed(listenRun, delay)
    }

    private var mutedStreams: List<Int> = emptyList()
    private val unmuteRun = Runnable { mute(false) }

    /** Silences the recognizer start/stop beep: mute now, unmute shortly after. Media volume is left alone while music plays. */
    private fun quiet(ms: Long) {
        mute(true)
        main.removeCallbacks(unmuteRun)
        main.postDelayed(unmuteRun, ms)
    }

    private fun mute(m: Boolean) {
        val a = am ?: return
        try {
            if (m) {
                if (muted) return
                val list = ArrayList<Int>()
                list.add(AudioManager.STREAM_NOTIFICATION)
                list.add(AudioManager.STREAM_SYSTEM)
                if (!a.isMusicActive) list.add(AudioManager.STREAM_MUSIC)
                mutedStreams = list
                for (st in list) {
                    try {
                        a.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, 0)
                    } catch (e: Exception) {
                    }
                }
                muted = true
            } else {
                if (!muted) return
                for (st in mutedStreams) {
                    try {
                        a.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, 0)
                    } catch (e: Exception) {
                    }
                }
                muted = false
            }
        } catch (e: Exception) {
        }
    }

    private fun count(p: Regex, t: String): Int = p.findAll(t).count()

    private fun prune(l: ArrayList<Long>, now: Long) {
        for (i in l.size - 1 downTo 0) if (now - l[i] > 10000) l.removeAt(i)
    }

    private fun beep() {
        val now = System.currentTimeMillis()
        if (now - lastBeep < 2500) return
        lastBeep = now
        try {
            val t = ToneGenerator(AudioManager.STREAM_ALARM, 70)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 200)
            main.postDelayed({ t.release() }, 400)
        } catch (e: Exception) {
        }
    }

    private fun scan(b: Bundle?, final: Boolean) {
        val r = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        if (r.isEmpty()) return
        val now = System.currentTimeMillis()
        val alts = r.map { it.lowercase() }
        if (alts[0].isNotBlank()) note(alts[0])
        if (handled) return

        // "siren bajao" / "siren band karo" work any time, no wake word needed, and act as soon as they are heard
        for (t in alts) {
            val sc = Commands.parse(t)
            if (sc == Cmd.SIREN_ON || sc == Cmd.SIREN_OFF) {
                handled = true
                Actions.run(this, sc, t)
                return
            }
        }

        // wake word, optionally followed by a command in the same breath
        var rest: String? = null
        var nb = 0
        var nh = 0
        for (t in alts) {
            val m = WAKE.find(t)
            if (m != null && rest == null) rest = t.substring(m.range.last + 1)
            nb = max(nb, count(BACHAO, t))
            nh = max(nh, count(HELP, t))
        }
        if (rest != null) {
            awaitUntil = now + 8000
            if (!final) {
                beep()
                val pc = Commands.parse(rest)
                if (pc == Cmd.SIREN_ON || pc == Cmd.SIREN_OFF || pc == Cmd.LOC_ON || pc == Cmd.LOC_OFF || pc == Cmd.SCAN || pc == Cmd.NEARBY) {
                    handled = true
                    awaitUntil = 0
                    Actions.run(this, pc, rest)
                }
            } else {
                val cmd = Commands.parse(rest)
                if (cmd != Cmd.NONE) {
                    awaitUntil = 0
                    Actions.run(this, cmd, rest)
                } else if (rest.trim().length > 3) {
                    awaitUntil = 0
                    Actions.run(this, Cmd.NONE, rest.trim())
                }
            }
            return
        }
        if (final && awaitUntil > now) {
            awaitUntil = 0
            val t = alts[0]
            Actions.run(this, Commands.parse(t), t)
            return
        }

        // bachao x3 / madad x3 within 10 seconds
        for (j in lastB until nb) bachao.add(now)
        for (j in lastH until nh) help.add(now)
        lastB = max(lastB, nb)
        lastH = max(lastH, nh)
        prune(bachao, now)
        prune(help, now)
        if (bachao.size >= 3) {
            bachao.clear()
            fire(false)
        } else if (help.size >= 3) {
            help.clear()
            fire(false)
        }
    }

    override fun onPartialResults(partialResults: Bundle?) = scan(partialResults, false)

    override fun onResults(results: Bundle?) {
        quiet(1500)
        scan(results, true)
        restart(150)
    }

    override fun onError(error: Int) {
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) note("(mic error " + error + ")")
        quiet(1500)
        restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 250)
    }

    override fun onReadyForSpeech(params: Bundle?) {}

    override fun onBeginningOfSpeech() {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {
        quiet(1500)
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    /** Cough = a short (80-500 ms) loud burst. Three within 10 s -> silent SOS (khansi sound). */
    override fun onRmsChanged(rmsdB: Float) {
        if (!wantCough) return
        val now = System.currentTimeMillis()
        if (rmsdB > 7f) {
            if (burstStart == 0L) burstStart = now
        } else if (burstStart != 0L) {
            val d = now - burstStart
            burstStart = 0L
            if (d > 80 && d < 500) {
                cough.add(now)
                prune(cough, now)
                if (cough.size >= 3) {
                    cough.clear()
                    fire(true)
                }
            }
        }
    }

    private fun fire(silent: Boolean) {
        val now = System.currentTimeMillis()
        if (now - lastSos < 120000) return
        lastSos = now
        val c = applicationContext
        Thread { Sos.dispatch(c, silent) }.start()
    }

    /* ---------------------------------------------------------- shake / fall */

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val m = sqrt(x * x + y * y + z * z)
        val n = System.currentTimeMillis()
        if (wantFall) {
            if (m < 3f) {
                freeFall = n
            } else if (m > 28f && freeFall != 0L && n - freeFall < 1000) {
                freeFall = 0L
                Actions.openUi(applicationContext, "fall", "")
                return
            }
        }
        if (wantShake && m > 24f && (shakes.isEmpty() || n - shakes[shakes.size - 1] > 220)) {
            shakes.add(n)
            for (i in shakes.size - 1 downTo 0) if (n - shakes[i] > 1700) shakes.removeAt(i)
            if (shakes.size >= 5) {
                shakes.clear()
                fire(false)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /* --------------------------------------------------------- live location */

    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            postLocation(location)
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("old platform callback")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }
    }

    private fun beginTracking() {
        try {
            lm?.removeUpdates(locListener)
        } catch (e: Exception) {
        }
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try {
                if (lm?.isProviderEnabled(p) == true) lm?.requestLocationUpdates(p, 4000L, 0f, locListener, Looper.getMainLooper())
            } catch (e: Exception) {
                // e.g. only approximate location granted: GPS is refused, network still works
            }
        }
        val l = Sos.lastLocation(this)
        if (l != null) postLocation(l)
        main.removeCallbacks(liveTick)
        main.postDelayed(liveTick, 3000)
    }

    private fun endTracking() {
        main.removeCallbacks(liveTick)
        try {
            lm?.removeUpdates(locListener)
        } catch (e: Exception) {
        }
        val id = Live.id(this)
        val relay = St.relay(this)
        Live.setOn(this, false)
        liveSent = false
        if (id.isNotEmpty()) Thread { Net.post("$relay/live/stop", JSONObject().put("id", id).toString()) }.start()
        applyIdleStop()
    }

    private fun applyIdleStop() {
        if (!wantListen && !wantShake && !wantFall && !Live.on(this)) stopSelf()
    }

    private fun postLocation(l: Location) {
        val id = Live.id(this)
        if (id.isEmpty() || !Live.on(this)) return
        val now = System.currentTimeMillis()
        if (now - lastPost < 4500) return
        lastPost = now
        val c = applicationContext
        val first = !liveSent
        Thread {
            val st = St.json(c)
            val relay = St.relay(c)
            val name = st.optString("name").ifEmpty { "User" }
            val code = st.optString("code")
            val o = JSONObject().put("id", id).put("name", name).put("lat", l.latitude).put("lng", l.longitude)
            if (first && code.length == 16) {
                o.put("code", code).put("ids", st.optJSONArray("tg") ?: JSONArray())
                if (Net.post("$relay/live/start", o.toString()) != null) liveSent = true
            } else {
                Net.post("$relay/track", o.toString())
                liveSent = true
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        mute(false)
        main.removeCallbacksAndMessages(null)
        try {
            sr?.destroy()
            sm?.unregisterListener(this)
            lm?.removeUpdates(locListener)
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
