plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jashpi.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jashpi.ai"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // Your relay server (https, no trailing slash). Set it with the JASHPI_RELAY env var / GitHub variable,
        // or edit the fallback below. It can also be changed later in Developer mode.
        val relay = System.getenv("JASHPI_RELAY")?.takeIf { it.isNotBlank() } ?: "https://YOUR-APP.onrender.com"
        buildConfigField("String", "RELAY_URL", "\"$relay\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Signed with the debug key so the APK installs directly (sideloading).
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // One-call QR / barcode scanner (no camera permission or camera code needed)
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
