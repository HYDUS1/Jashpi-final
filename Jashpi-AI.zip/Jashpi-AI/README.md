# Jashpi AI

Android app (Kotlin + Gradle) with a small Node relay server.

```
app/        Android app  (Kotlin, simple HTML UI in app/src/main/assets/www)
server/     Relay: Telegram bot, SOS fan-out, live-location page, AI proxy, developer config
.github/    GitHub Actions workflow that builds the APK
```

## 1. Get the APK (GitHub)
1. Replace the contents of your `HYDUS1/Jashpi.AI` repo with this folder (keep the `.github` folder) and push to `main`.
2. Open **Actions → Build APK → latest run → Artifacts → Jashpi-AI-apk**. Download, unzip, install the APK on your phone.
3. (Recommended) Repo **Settings → Secrets and variables → Actions → Variables → New variable**: `JASHPI_RELAY` = your server URL (see below). Re-run the workflow so the URL is baked into the app. If you skip this, set the Relay URL in Developer mode inside the app.

The old error ("No file matched … gradle-wrapper.properties") happened because the repo had no Gradle project. This workflow installs Gradle itself, so no `gradlew` is needed.

## 2. Server (Render)
1. New Web Service from the repo, root directory `server`, start command `node server.js` (or use `server/render.yaml`).
2. Add a persistent disk mounted at `/data` and env `DATA_DIR=/data` (otherwise linked Telegram contacts and settings are lost on restart).
3. Optional env `BOT_TOKEN`. You can also set the bot token and AI key later from the app in Developer mode; they apply to all users.
4. Use a paid/always-on instance: free instances sleep and Telegram messages can be delayed.

## 3. Developer mode
Type the developer code into the **name** field (first launch, or Settings → name → Save). Settings then shows a Developer section: relay URL, Telegram bot token, AI provider / model / API key. "Save for everyone" stores them on your server, so every user's app uses them. The API key never goes to user phones.
Only the SHA-256 hash of the code is in the app and server.

## Voice commands
Say "Hello Jashpi" then: `siren bajao`, `siren band karo`, `sos bhejo`, `location share karo`, `location band karo`, `scan karo`, `call karo`, or any question.
Always on: "Bachao" x3 or "Madad/Help" x3 within 10 s = SOS. Three coughs = silent SOS. "siren band karo" works without the wake word.
Siren can only be started by voice.
